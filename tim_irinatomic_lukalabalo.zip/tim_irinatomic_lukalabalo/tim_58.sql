/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     4/12/2023 2:41:31 PM                         */
/*==============================================================*/


drop table if exists EPIZODE;

drop table if exists FILMOVI;

drop table if exists IZDAVACKE_KUCE;

drop table if exists IZNAMLJENI;

drop table if exists KANALI;

drop table if exists KORISNICI;

drop table if exists MEDIJI;

drop table if exists OMILJENI_KANALI;

drop table if exists OSTALI_SADRZAJI;

drop table if exists PAKETI;

drop table if exists POPUSTI;

drop table if exists PRIKAZIVANJA;

drop table if exists SERIJE;

drop table if exists SEZONE;

drop table if exists TIME_SLOTOVI;

drop table if exists TIPOVI_KANALA;

drop table if exists TIPOVI_PAKETA;

drop table if exists TIPOVI_PLACANJA;

drop table if exists ULAZI_U_TIP_PAKETA;

drop table if exists UPLATE;

drop table if exists ZANRA;

drop table if exists ZANROVI;

/*==============================================================*/
/* Table: EPIZODE                                               */
/*==============================================================*/
create table EPIZODE
(
   SERIJA_ID            int not null,
   SEZONA_ID            int not null,
   MEDIJA_ID            int not null,
   EPIZODA_ID           int not null,
   BROJ_EPIZODE         numeric(4,0) not null,
   IZDAVACKA_KUCA_ID    int,
   CENA                 int not null,
   NAZIV                char(50),
   OPIS                 varchar(255),
   VREME_TRAJANJA_MIN   numeric(4,0),
   primary key (SERIJA_ID, SEZONA_ID, MEDIJA_ID, EPIZODA_ID)
);

/*==============================================================*/
/* Table: FILMOVI                                               */
/*==============================================================*/
create table FILMOVI
(
   MEDIJA_ID            int not null,
   FILM_ID              int not null,
   GOD_IZDANJA          numeric(4,0) not null,
   IZDAVACKA_KUCA_ID    int,
   CENA                 int not null,
   NAZIV                char(50),
   OPIS                 varchar(255),
   VREME_TRAJANJA_MIN   numeric(4,0),
   primary key (MEDIJA_ID, FILM_ID)
);

/*==============================================================*/
/* Table: IZDAVACKE_KUCE                                        */
/*==============================================================*/
create table IZDAVACKE_KUCE
(
   IZDAVACKA_KUCA_ID    int not null,
   NAZIV                char(50) not null,
   GODINA_OSNIVANJA     numeric(4,0) not null,
   SEDISTE              varchar(30) not null,
   primary key (IZDAVACKA_KUCA_ID)
);

/*==============================================================*/
/* Table: IZNAMLJENI                                            */
/*==============================================================*/
create table IZNAMLJENI
(
   KORISNIK_ID          int not null,
   MEDIJA_ID            int not null,
   IZNAMLJENO_ID        int not null,
   DATUM                date not null,
   primary key (KORISNIK_ID, MEDIJA_ID, IZNAMLJENO_ID)
);

/*==============================================================*/
/* Table: KANALI                                                */
/*==============================================================*/
create table KANALI
(
   KANAL_ID             char(2) not null,
   IZDAVACKA_KUCA_ID    int not null,
   TIP_KANALA_ID        int not null,
   NAZIV                char(50),
   primary key (KANAL_ID)
);

/*==============================================================*/
/* Table: KORISNICI                                             */
/*==============================================================*/
create table KORISNICI
(
   KORISNIK_ID          int not null,
   POPUST_ID            char(2),
   TIP_PAKETA_ID        char(2) not null,
   PAKET_ID             char(2) not null,
   IME                  varchar(30) not null,
   PREZIME              varchar(30) not null,
   JMBG                 char(13) not null,
   BR_TELEFONA          varchar(15),
   KORISIK_OD           numeric(4,0) not null,
   primary key (KORISNIK_ID)
);

/*==============================================================*/
/* Table: MEDIJI                                                */
/*==============================================================*/
create table MEDIJI
(
   MEDIJA_ID            int not null,
   IZDAVACKA_KUCA_ID    int not null,
   CENA                 int not null,
   NAZIV                char(50),
   OPIS                 varchar(255),
   VREME_TRAJANJA_MIN   numeric(4,0),
   primary key (MEDIJA_ID)
);

/*==============================================================*/
/* Table: OMILJENI_KANALI                                       */
/*==============================================================*/
create table OMILJENI_KANALI
(
   KANAL_ID             char(2) not null,
   KORISNIK_ID          int not null,
   OMILJENI_ID          int not null,
   primary key (KANAL_ID, KORISNIK_ID, OMILJENI_ID)
);

/*==============================================================*/
/* Table: OSTALI_SADRZAJI                                       */
/*==============================================================*/
create table OSTALI_SADRZAJI
(
   MEDIJA_ID            int not null,
   OSTALI_SADRZAJ_ID    int not null,
   IZDAVACKA_KUCA_ID    int,
   CENA                 int not null,
   NAZIV                char(50),
   OPIS                 varchar(255),
   VREME_TRAJANJA_MIN   numeric(4,0),
   primary key (MEDIJA_ID, OSTALI_SADRZAJ_ID)
);

/*==============================================================*/
/* Table: PAKETI                                                */
/*==============================================================*/
create table PAKETI
(
   TIP_PAKETA_ID        char(2) not null,
   PAKET_ID             char(2) not null,
   NAZIV                char(50),
   primary key (TIP_PAKETA_ID, PAKET_ID)
);

/*==============================================================*/
/* Table: POPUSTI                                               */
/*==============================================================*/
create table POPUSTI
(
   POPUST_ID            char(2) not null,
   NAZIV                char(50) not null,
   PROCENAT             decimal(3,2) not null,
   primary key (POPUST_ID)
);

/*==============================================================*/
/* Table: PRIKAZIVANJA                                          */
/*==============================================================*/
create table PRIKAZIVANJA
(
   VREME_PRIKAZA_ID     int not null,
   MEDIJA_ID            int not null,
   KANAL_ID             char(2) not null,
   primary key (VREME_PRIKAZA_ID, MEDIJA_ID, KANAL_ID)
);

/*==============================================================*/
/* Table: SERIJE                                                */
/*==============================================================*/
create table SERIJE
(
   SERIJA_ID            int not null,
   NAZIV                char(50) not null,
   OPIS                 varchar(255) not null,
   primary key (SERIJA_ID)
);

/*==============================================================*/
/* Table: SEZONE                                                */
/*==============================================================*/
create table SEZONE
(
   SERIJA_ID            int not null,
   SEZONA_ID            int not null,
   BROJ_SEZONE          numeric(3,0) not null,
   primary key (SERIJA_ID, SEZONA_ID)
);

/*==============================================================*/
/* Table: TIME_SLOTOVI                                          */
/*==============================================================*/
create table TIME_SLOTOVI
(
   VREME_PRIKAZA_ID     int not null,
   VREME                datetime not null,
   primary key (VREME_PRIKAZA_ID)
);

/*==============================================================*/
/* Table: TIPOVI_KANALA                                         */
/*==============================================================*/
create table TIPOVI_KANALA
(
   TIP_KANALA_ID        int not null,
   NAZIV                char(50) not null,
   primary key (TIP_KANALA_ID)
);

/*==============================================================*/
/* Table: TIPOVI_PAKETA                                         */
/*==============================================================*/
create table TIPOVI_PAKETA
(
   TIP_PAKETA_ID        char(2) not null,
   NAZIV                char(50) not null,
   CENA                 int not null,
   primary key (TIP_PAKETA_ID)
);

/*==============================================================*/
/* Table: TIPOVI_PLACANJA                                       */
/*==============================================================*/
create table TIPOVI_PLACANJA
(
   TIP_PLACANJA_ID      char(2) not null,
   NAZIV                char(50),
   primary key (TIP_PLACANJA_ID)
);

/*==============================================================*/
/* Table: ULAZI_U_TIP_PAKETA                                    */
/*==============================================================*/
create table ULAZI_U_TIP_PAKETA
(
   KANAL_ID             char(2) not null,
   TIP_PAKETA_ID        char(2) not null,
   primary key (KANAL_ID, TIP_PAKETA_ID)
);

/*==============================================================*/
/* Table: UPLATE                                                */
/*==============================================================*/
create table UPLATE
(
   KORISNIK_ID          int not null,
   TIP_PLACANJA_ID      char(2) not null,
   UPLATA_ID            int not null,
   IZN_KORISNIK_ID      int,
   MEDIJA_ID            int,
   IZNAMLJENO_ID        int,
   TIP_PAKETA_ID        char(2),
   PAKET_ID             char(2),
   POPUST_ID            char(2),
   DATUM_UPLATE         date not null,
   primary key (KORISNIK_ID, TIP_PLACANJA_ID, UPLATA_ID)
);

/*==============================================================*/
/* Table: ZANRA                                                 */
/*==============================================================*/
create table ZANRA
(
   ZANR_ID              char(2) not null,
   MEDIJA_ID            int not null,
   primary key (ZANR_ID, MEDIJA_ID)
);

/*==============================================================*/
/* Table: ZANROVI                                               */
/*==============================================================*/
create table ZANROVI
(
   ZANR_ID              char(2) not null,
   NAZIV                char(50) not null,
   primary key (ZANR_ID)
);

alter table EPIZODE add constraint FK_JESTE foreign key (MEDIJA_ID)
      references MEDIJI (MEDIJA_ID) on delete restrict on update restrict;

alter table EPIZODE add constraint FK_PRIPADA_SEZONI foreign key (SERIJA_ID, SEZONA_ID)
      references SEZONE (SERIJA_ID, SEZONA_ID) on delete restrict on update restrict;

alter table FILMOVI add constraint FK_JESTE2 foreign key (MEDIJA_ID)
      references MEDIJI (MEDIJA_ID) on delete restrict on update restrict;

alter table IZNAMLJENI add constraint FK_IZNAJMIO_JE foreign key (KORISNIK_ID)
      references KORISNICI (KORISNIK_ID) on delete restrict on update restrict;

alter table IZNAMLJENI add constraint FK_IZNANLJEN_JE foreign key (MEDIJA_ID)
      references MEDIJI (MEDIJA_ID) on delete restrict on update restrict;

alter table KANALI add constraint FK_DRZI foreign key (IZDAVACKA_KUCA_ID)
      references IZDAVACKE_KUCE (IZDAVACKA_KUCA_ID) on delete restrict on update restrict;

alter table KANALI add constraint FK_JE_TIPA foreign key (TIP_KANALA_ID)
      references TIPOVI_KANALA (TIP_KANALA_ID) on delete restrict on update restrict;

alter table KORISNICI add constraint FK_IMA_PAKET foreign key (TIP_PAKETA_ID, PAKET_ID)
      references PAKETI (TIP_PAKETA_ID, PAKET_ID) on delete restrict on update restrict;

alter table KORISNICI add constraint FK_IMA_POPUST foreign key (POPUST_ID)
      references POPUSTI (POPUST_ID) on delete restrict on update restrict;

alter table MEDIJI add constraint FK_DRZI_MEDIJA foreign key (IZDAVACKA_KUCA_ID)
      references IZDAVACKE_KUCE (IZDAVACKA_KUCA_ID) on delete restrict on update restrict;

alter table OMILJENI_KANALI add constraint FK_JE_OMILJEN foreign key (KANAL_ID)
      references KANALI (KANAL_ID) on delete restrict on update restrict;

alter table OMILJENI_KANALI add constraint FK__ foreign key (KORISNIK_ID)
      references KORISNICI (KORISNIK_ID) on delete restrict on update restrict;

alter table OSTALI_SADRZAJI add constraint FK_JESTE3 foreign key (MEDIJA_ID)
      references MEDIJI (MEDIJA_ID) on delete restrict on update restrict;

alter table PAKETI add constraint FK_JE_TIPA_PAKETA foreign key (TIP_PAKETA_ID)
      references TIPOVI_PAKETA (TIP_PAKETA_ID) on delete restrict on update restrict;

alter table PRIKAZIVANJA add constraint FK_NA_KANALU foreign key (KANAL_ID)
      references KANALI (KANAL_ID) on delete restrict on update restrict;

alter table PRIKAZIVANJA add constraint FK_PRIKAZUJE_SE foreign key (MEDIJA_ID)
      references MEDIJI (MEDIJA_ID) on delete restrict on update restrict;

alter table PRIKAZIVANJA add constraint FK_SATNICA foreign key (VREME_PRIKAZA_ID)
      references TIME_SLOTOVI (VREME_PRIKAZA_ID) on delete restrict on update restrict;

alter table SEZONE add constraint FK_PRIPADA_SERIJI foreign key (SERIJA_ID)
      references SERIJE (SERIJA_ID) on delete restrict on update restrict;

alter table ULAZI_U_TIP_PAKETA add constraint FK_ULAZI_U_TIP_PAKETA foreign key (KANAL_ID)
      references KANALI (KANAL_ID) on delete restrict on update restrict;

alter table ULAZI_U_TIP_PAKETA add constraint FK_ULAZI_U_TIP_PAKETA2 foreign key (TIP_PAKETA_ID)
      references TIPOVI_PAKETA (TIP_PAKETA_ID) on delete restrict on update restrict;

alter table UPLATE add constraint FK_OSTVARENI_POPUSTI foreign key (POPUST_ID)
      references POPUSTI (POPUST_ID) on delete restrict on update restrict;

alter table UPLATE add constraint FK_RELATIONSHIP_21 foreign key (TIP_PAKETA_ID, PAKET_ID)
      references PAKETI (TIP_PAKETA_ID, PAKET_ID) on delete restrict on update restrict;

alter table UPLATE add constraint FK_RELATIONSHIP_22 foreign key (IZN_KORISNIK_ID, MEDIJA_ID, IZNAMLJENO_ID)
      references IZNAMLJENI (KORISNIK_ID, MEDIJA_ID, IZNAMLJENO_ID) on delete restrict on update restrict;

alter table UPLATE add constraint FK_TIP_PLACANJA foreign key (TIP_PLACANJA_ID)
      references TIPOVI_PLACANJA (TIP_PLACANJA_ID) on delete restrict on update restrict;

alter table UPLATE add constraint FK_UPLATIO foreign key (KORISNIK_ID)
      references KORISNICI (KORISNIK_ID) on delete restrict on update restrict;

alter table ZANRA add constraint FK_ZANRA foreign key (ZANR_ID)
      references ZANROVI (ZANR_ID) on delete restrict on update restrict;

alter table ZANRA add constraint FK_ZANRA2 foreign key (MEDIJA_ID)
      references MEDIJI (MEDIJA_ID) on delete restrict on update restrict;

